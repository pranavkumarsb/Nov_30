package com.practice.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.practice.bean.RegistrationBean;

@Controller
public class FormController {
	
	@RequestMapping("/")
	public ModelAndView showForm() {
        return new ModelAndView("register", "registerForm", new RegistrationBean());
    }

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView loadForm(@Valid @ModelAttribute("registerUser")RegistrationBean registerbean, BindingResult result, ModelMap model)
	{	
		ModelAndView modelandview = new ModelAndView("registerUser");
		if(result.hasErrors())
		{
			modelandview.setViewName("register");
			return modelandview;
		}
		model.addAttribute("firstname",registerbean.getFirstName());
		model.addAttribute("lastname",registerbean.getLastName());
		model.addAttribute("gender",registerbean.getGender());
		model.addAttribute("dateofbirth",registerbean.getDateOfBirth());
		model.addAttribute("amount",registerbean.getAmount());
		modelandview.addAllObjects(model);
		modelandview.setViewName("register");
		return modelandview;
	}
	
	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public ModelAndView registerPage(@ModelAttribute("registerUser")RegistrationBean registerbean, BindingResult result, ModelMap model)
	{	
		ModelAndView modelandview = new ModelAndView("registerUser");
		model.addAttribute("firstname",registerbean.getFirstName());
		model.addAttribute("lastname",registerbean.getLastName());
		model.addAttribute("gender",registerbean.getGender());
		model.addAttribute("dateofbirth",registerbean.getDateOfBirth());
		model.addAttribute("amount",registerbean.getAmount());
		modelandview.addAllObjects(model);
		modelandview.setViewName("successpage");
		return modelandview;
	}
}